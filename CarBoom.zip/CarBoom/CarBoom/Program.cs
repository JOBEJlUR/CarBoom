﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace CarBoom
{
    class Program
    {
        [DllImport("user32.dll")]
        static extern short GetAsyncKeyState(int vKey);

        static VAMemory mem;
        static int SampDll;

        private static int oCPEDVehicle = 0xBA18FC;
        private static int oVehicleHealth = 0x4C0;
        private static int adress;

        static void Main(string[] args)
        {
            Console.Write("Введите виртуальный код клавиши:");
            int key = Convert.ToInt32(Console.ReadLine());
            while (!GetDll())
            {

            }
            while(true)
            {
                if (GetAsyncKeyState(key) != 0)
                {
                    Boom(0);
                }
            }
        }
        static bool GetDll()
        {
            try
            {
                Process Warcraft = Process.GetProcessesByName("gta")[0];
                mem = new VAMemory("gta");
                foreach (ProcessModule module in Warcraft.Modules)
                {
                    if (module.ModuleName == "samp.dll")
                    {
                        SampDll = (int)module.BaseAddress;
                    }

                }
                return true;
            }
            catch
            {
                return false;
            }

        }
        static void Boom(float health)
        {
            int Vehicle = mem.ReadInt32((IntPtr)oCPEDVehicle);
            adress = Vehicle + oVehicleHealth;
            mem.WriteFloat((IntPtr)adress, health);
        }
    }
    
}
